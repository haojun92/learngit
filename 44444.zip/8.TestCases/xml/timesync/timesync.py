import time, os, msvcrt,re,locale
from win32com.client import *
from win32com.client.connect import *
import paramiko
from datetime import datetime, timedelta

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_two_dir = os.path.join(current_dir, "..", "..", "..")
cfg_path = os.path.join(parent_two_dir, "Project_J6P.cfg")
cfg_path = os.path.abspath(cfg_path)
print(cfg_path)
app = win32com.client.Dispatch("CANoe.Application")
LOG_FILENAME = f"sync_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
HOST = "10.43.0.28"
USER = "root"
PWD = ""
test_records = []
total_pass = 0
total_fail = 0

def ssh_connect():
    retry = 0
    while True:
        try:
            transport = paramiko.Transport((HOST, 22))
            transport.connect(username=USER, password=PWD)
            client = paramiko.SSHClient()
            client._transport = transport
            print("SSH 连接成功！")
            return client, transport
        except Exception as e:
            retry += 1
            print(f"SSH 未准备好，重试中... {retry}")
            time.sleep(3)

def exec_cmd(client, cmd):
    stdin, stdout, stderr = client.exec_command(cmd)
    output = stdout.read().decode().strip()
    error = stderr.read().decode().strip()
    result = output + error if error else output
    with open(LOG_FILENAME, "a", encoding="utf-8") as f:
        f.write(f"========================================\n")
        f.write(f"执行时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"执行命令：{cmd}\n")
        f.write(f"执行结果：{result}\n")
        f.write(f"========================================\n\n")
    return output

def get_rtc_time(client):
    output = exec_cmd(client, "timedatectl")
    matches = re.findall(r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})", output)
    if matches:
        return datetime.strptime(matches[-1], "%Y-%m-%d %H:%M:%S") + timedelta(hours=8)
    return None

def get_mcu_time(client):
    output = exec_cmd(client, "cat /log/mcu/message | grep Datatime")
    time.sleep(.1)
    matches = re.findall(r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}):\s*(\d+)", output)
    #formatted = [t.replace(": ", ":") for t in matches]
    #mcu时间，取最新时间,最右打印时间（底软存在夏令时问题）
    times_MCU = []
    times_MCU_list = []    
    formatted_times = []
    for prefix, ms in matches:
        ms_fixed = f"{int(ms):02d}"  # 毫秒 1 位 → 补 0 成 2 位
        final_time = f"{prefix}:{ms_fixed}"
        formatted_times.append(final_time) 
    for time_str in formatted_times:
        dt_ms = datetime.strptime(str(time_str), "%Y-%m-%d %H:%M:%S:%f")
        dt = dt_ms.strftime("%Y-%m-%d %H:%M:%S")
        times_MCU.append(dt)     
        times_MCU_list.append(dt_ms) 
# -------------------------- MCU时间连续性检测 --------------------------
    if len(times_MCU_list)>1:
        for i in range(1, len(times_MCU_list)):
            prev = times_MCU_list[i-1]
            curr = times_MCU_list[i]
            delta = (curr - prev).total_seconds()
        if 4 < delta < 6:
        #时间间隔正常           
            return datetime.strptime(times_MCU[-1], "%Y-%m-%d %H:%M:%S")
        else:
            print("MCU时间间隔有变")
    return datetime.strptime(times_MCU[-1], "%Y-%m-%d %H:%M:%S")

def get_soc_time(client):
    output = exec_cmd(client, "phc_ctl /dev/ptp0 get")
    match = re.search(r"[A-Za-z]{3} [A-Za-z]{3}[ ]+\d{1,2} \d{2}:\d{2}:\d{2} \d{4}", output)
    locale.setlocale(locale.LC_TIME, 'english')
    if match:
        return datetime.strptime(match.group(), "%a %b %d %H:%M:%S %Y")
    return None

def get_Management_time(client):
    output = exec_cmd(client, "date")#Wed Apr  1 16:59:55 CST 2026
    match = re.search(r"([A-Za-z]{3}) ([A-Za-z]{3})[ ]+(\d{1,2}) (\d{2}:\d{2}:\d{2}) [A-Z]+ (\d{4})",output)
    clean_time = match.group().replace(" CST "," ")
    clean_time = clean_time.replace("\n","")
    locale.setlocale(locale.LC_TIME, 'english')
    if match:
        return datetime.strptime(clean_time, "%a %b %d %H:%M:%S %Y")
    return None

def send_can_510():
    cansys = app.System
    cannamespaces = cansys.Namespaces
    cannamespace = cannamespaces.Item("ICC8")
    canvariables = cannamespace.Variables
    canvar = canvariables.Item("send")
    canvar.Value = 1

def stop_can_510():
    cansys = app.System
    cannamespaces = cansys.Namespaces
    cannamespace = cannamespaces.Item("ICC8")
    canvariables = cannamespace.Variables
    canvar = canvariables.Item("send")
    canvar.Value = 0

def send_can_nm():
    cansys = app.System
    cannamespaces = cansys.Namespaces
    cannamespace = cannamespaces.Item("ICC8")
    canvariables = cannamespace.Variables
    canvar = canvariables.Item("send_nm")
    canvar.Value = 1

def stop_can_nm():
    cansys = app.System
    cannamespaces = cansys.Namespaces
    cannamespace = cannamespaces.Item("ICC8")
    canvariables = cannamespace.Variables
    canvar = canvariables.Item("send_nm")
    canvar.Value = 0

def canone_set_ICC8(year,month,day,hour,minute,second):
    cansys = app.System
    cannamespaces = cansys.Namespaces
    cannamespace = cannamespaces.Item("ICC8")
    canvariables = cannamespace.Variables
    canvar = canvariables.Item("set")
    canvar.Value = 1
    canvar = canvariables.Item("setyear")
    canvar.Value = year
    canvar = canvariables.Item("setmonth")
    canvar.Value = month
    canvar = canvariables.Item("setday")
    canvar.Value = day
    canvar = canvariables.Item("sethour")
    canvar.Value = hour
    canvar = canvariables.Item("setminute")
    canvar.Value = minute
    canvar = canvariables.Item("setsecond")
    canvar.Value = second

def canoetime():
    cansys = app.System
    cannamespaces = cansys.Namespaces
    cannamespace = cannamespaces.Item("timenow")
    canvariables = cannamespace.Variables
    canvar = canvariables.Item("time")
    return canvar.Value

def RRCRtime():
    cansys = app.System
    cannamespaces = cansys.Namespaces
    cannamespace = cannamespaces.Item("ICC8")
    canvariables = cannamespace.Variables
    canvar = canvariables.Item("RRCR")
    return canvar.Value

def RLCRtime():
    cansys = app.System
    cannamespaces = cansys.Namespaces
    cannamespace = cannamespaces.Item("ICC8")
    canvariables = cannamespace.Variables
    canvar = canvariables.Item("RLCR")
    return canvar.Value

def reboot(client,transport):
    exec_cmd(client, "reboot")
    print(f"\n 发送reboot重启")
    transport.close()
    print(f"\n 等待重启")
    time.sleep(3)
    client_REBOOT, transport_REBOOT = ssh_connect()
    return client_REBOOT, transport_REBOOT

def sync_reboot(set_time):
    client, transport = ssh_connect()
    print("发送ICC_COM_8")
    if set_time ==0:
        send_can_510()
    else:
        canone_set_ICC8(set_time.year,set_time.month,set_time.day,set_time.hour,set_time.minute,set_time.second)
        send_can_510()
    client_REBOOT, transport_REBOOT = reboot(client,transport)
    try:
        rtc = get_rtc_time(client_REBOOT)
        mcu = get_mcu_time(client_REBOOT)
        soc = get_soc_time(client_REBOOT)
        Management = get_Management_time(client_REBOOT)
        return rtc,mcu,soc,Management
    finally:
        stop_can_510()
        transport_REBOOT.close()

def result(case_name,ifneedsync, soc, mcu, rtc, Management,set_time=None, check_icc=True):
    # ========== 域控内部同步 ==========
    delta_SOC = soc - rtc
    delta_MCU = mcu - rtc
    delta_Management = Management - rtc

    inner_ok = (-1<=delta_SOC.total_seconds()<=1 and 
                -1<=delta_MCU.total_seconds()<=1 and 
                -1<=delta_Management.total_seconds()<=1)
    inner_res = "PASS" if inner_ok else "FAIL"
    inner_err = f"SOC={delta_SOC.total_seconds():.2f}s MCU={delta_MCU.total_seconds():.2f}s MGMT={delta_Management.total_seconds():.2f}s" if not inner_ok else "-"
    
    print(f"\n【{case_name}】内部同步：{inner_res}")

    # ========== ICC同步 ==========
    if check_icc and set_time is not None:
        delta_ICC = rtc - set_time
        icc_ok = -1<=delta_ICC.total_seconds()<=1
        if ifneedsync:
            icc_res = "PASS" if icc_ok else "FAIL"
        else:
            icc_res = "FAIL" if icc_ok else "PASS"
        icc_err = f"ICC差值={delta_ICC.total_seconds():.2f}s" if icc_res == "FAIL" else "-"
        icc_flag = "YES" if ifneedsync == 1 else "NO" 
        print(f"【{case_name}】ICC同步：{icc_res}")
    else:
        # 不校验ICC
        icc_res = "-"
        icc_err = "-"
        icc_flag = "-"
        set_time = None
        print(f"【{case_name}】ICC同步：不校验")

    # 写入测试记录
    add_test_record(case_name, set_time, rtc, soc, mcu, Management, inner_res, icc_res, inner_err, icc_err, icc_flag)

def add_test_record(case_name, set_time, rtc, soc, mcu, mgmt, inner_res, icc_res, inner_err, icc_err, icc_flag):
    test_records.append({
        "case": case_name,
        "set_time": set_time.strftime("%Y-%m-%d %H:%M:%S") if set_time else "-",
        "rtc": rtc.strftime("%Y-%m-%d %H:%M:%S") if rtc else "-",
        "soc": soc.strftime("%Y-%m-%d %H:%M:%S") if soc else "-",
        "mcu": mcu.strftime("%Y-%m-%d %H:%M:%S") if mcu else "-",
        "mgmt": mgmt.strftime("%Y-%m-%d %H:%M:%S") if mgmt else "-",
        "inner_res": inner_res,
        "icc_res": icc_res,
        "icc_flag": icc_flag,  # 0/1/-
        "err": f"内部：{inner_err} | ICC：{icc_err}"
    })

def generate_html_report():
    if not test_records:
        print("无测试记录！")
        return

    filename = f"时间同步测试报告_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
    html = f"""<html>
<head>
    <meta charset="utf-8">
    <title>时间同步测试报告</title>
    <style>
        body {{font-family: Microsoft YaHei; margin:30px; background:#f5f5f5;}}
        .container {{background:white; padding:25px; border-radius:10px;}}
        table {{width:100%; border-collapse:collapse; margin-top:20px;}}
        th,td {{border:1px solid #ddd; padding:10px; text-align:center;}}
        th {{background:#3498db; color:white;}}
        .pass {{color:green; font-weight:bold;}}
        .fail {{color:red; font-weight:bold;}}
        .na {{color:#666;}}
    </style>
</head>
<body>
    <div class="container">
        <h1>域控时间同步测试报告</h1>
        <table>
            <tr>
                <th>测试用例</th>
                <th>设定ICC时间</th>
                <th>ICC是否需要同步</th> <!-- 新增列 -->
                <th>RTC时间</th>
                <th>SOC时间</th>
                <th>MCU时间</th>
                <th>Management时间</th>
                <th>内部同步结果</th>
                <th>ICC同步结果</th>
                <th>失败信息</th>
            </tr>"""

    for r in test_records:
        inner_cls = "pass" if r["inner_res"] == "PASS" else "fail"
        icc_cls = "pass" if r["icc_res"] == "PASS" else ("fail" if r["icc_res"] == "FAIL" else "na")

        html += f"""
        <tr>
            <td>{r['case']}</td>
            <td>{r['set_time']}</td>
            <td class='na'>{r['icc_flag']}</td> <!-- 显示0/1/- -->
            <td>{r['rtc']}</td>
            <td>{r['soc']}</td>
            <td>{r['mcu']}</td>
            <td>{r['mgmt']}</td>
            <td class='{inner_cls}'>{r['inner_res']}</td>
            <td class='{icc_cls}'>{r['icc_res']}</td>
            <td>{r['err']}</td>
        </tr>"""

    html += "</table></div></body></html>"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"\n测试报告已生成：{filename}")

# -----------------------------------------------------------------------------
# 测试用例 1
# -----------------------------------------------------------------------------
def test_case_1():
    print("---------------TC_Timesync_01_001---------------------")
    print("检查4s内没有收到ICC_COM_8报文，时间戳是否从NvM里读上次的值")

    client, transport = ssh_connect()
    try:
        rtc = get_rtc_time(client)
        mcu = get_mcu_time(client)
        soc = get_soc_time(client)
        Management = get_Management_time(client)
        result("TC_Timesync_01_001",1, soc, mcu, rtc, Management,None,check_icc=False)
    finally:
        transport.close()

def test_case_2():
    print("---------------TC_Timesync_01_002---------------------")
    print("检查4s后发送早于RTC时间的ICC_COM_8，时间戳是否未被同步到域控数据面")

    set_time = datetime(2001,3,11,23,59,11)
    rtc,mcu,soc,Management = sync_reboot(set_time)
    result("TC_Timesync_01_002",0,soc,mcu,rtc,Management,set_time,check_icc=True)

def test_case_4():
    print("---------------TC_Timesync_01_004---------------------")
    print("检查4s内发送晚于RTC时间的ICC_COM_8，时间戳是否被同步到域控数据面")

    rtc,mcu,soc,Management = sync_reboot(0)
    set_time_str = canoetime()
    set_time = datetime.strptime(set_time_str, "%Y-%m-%d_%H:%M:%S")
    result("TC_Timesync_01_004",1,soc,mcu,rtc,Management,set_time,check_icc=True)

def test_case_5():
    print("---------------TC_Timesync_01_005---------------------")
    print("检查4s后继续发送ICC_COM_8报文，时间戳是否同步到域控数据面时钟")

    rtc,mcu,soc,Management = sync_reboot(0)
    set_time_str = canoetime()
    set_time = datetime.strptime(set_time_str, "%Y-%m-%d_%H:%M:%S")
    result("TC_Timesync_01_005",1,soc,mcu,rtc,Management,set_time,check_icc=True)
    time.sleep(5)
    set_time_future = datetime(2028,3,11,23,59,11)
    canone_set_ICC8(2028,3,11,23,59,11)
    time.sleep(.5)
    send_can_510()
    result("TC_Timesync_01_005",0,soc,mcu,rtc,Management,set_time_future,check_icc=True)
    stop_can_510()     

def test_case_6():
    print("---------------TC_Timesync_01_006---------------------")
    print("SOC与MCU时间同步偏差稳定收敛")    

    fail_records = []
    client, transport = ssh_connect()
    
    # 执行10次测试
    for i in range(1, 11):
        soc = get_soc_time(client)
        mcu = get_mcu_time(client)
        
        # 仅最后一次保留时间值用于报告表格展示
        if i == 10:
            final_soc = soc
            final_mcu = mcu
            final_rtc = get_rtc_time(client)
            final_mgmt = get_Management_time(client)
        
        soc_time_str = soc.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        mcu_time_str = mcu.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        
        delta_sec = (mcu - soc).total_seconds()
        if not (-1 <= delta_sec <= 1):
            fail_records.append([i, soc_time_str, mcu_time_str])

    transport.close()

    if len(fail_records) == 0:
        inner_res = "PASS"
        fail_msg = "SOC与MCU时间同步偏差稳定收敛（10次测试全部合格）"
        print("\nPASS：SOC与MCU时间同步偏差稳定收敛")
    else:
        inner_res = "FAIL"
        fail_details = []
        for item in fail_records:
            fail_details.append(f"第{item[0]}次 | SOC时间={item[1]} | MCU时间={item[2]}")
        fail_msg = "<br>".join(fail_details)
        print(f"\nFAIL：SOC与MCU时间同步偏差不稳定 | 异常详情：{fail_msg}")

    add_test_record(
        case_name="TC_Timesync_01_006",
        set_time=None,
        rtc=final_rtc,
        soc=final_soc,
        mcu=final_mcu,
        mgmt=final_mgmt,
        inner_res=inner_res,
        icc_res="-",
        inner_err=fail_msg,
        icc_err="-",
        icc_flag="-"
    )

def test_case_7():
    print("---------------TC_Timesync_01_007---------------------")
    print("时间同步后，重启域控，查看SOC与MCU数据面时间是否跳变")

    rtc,mcu,soc,Management = sync_reboot(0)
    set_time_str = canoetime()
    set_time = datetime.strptime(set_time_str, "%Y-%m-%d_%H:%M:%S")
    result("TC_Timesync_01_007",1,soc,mcu,rtc,Management,set_time,check_icc=True)

    set_time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    set_time = datetime.strptime(set_time_str, "%Y-%m-%d %H:%M:%S") + timedelta(seconds=5)
    rtc,mcu,soc,Management = sync_reboot(set_time)
    result("TC_Timesync_01_007",1,soc,mcu,rtc,Management,set_time,check_icc=True)

def test_case_13():
    print("---------------TC_Timesync_01_013---------------------")
    print("角雷达时间同步")

    send_can_nm()
    rtc,mcu,soc,Management = sync_reboot(0)
    set_time_str = canoetime()
    set_time = datetime.strptime(set_time_str, "%Y-%m-%d_%H:%M:%S")
    result("TC_Timesync_01_013",1,soc,mcu,rtc,Management,set_time,check_icc=True)

    RRCR_timestamp = RRCRtime()
    RRCR_time = datetime.fromtimestamp(RRCR_timestamp/1000).replace(microsecond=0)
    delta_RRCR = RRCR_time - set_time

    RLCR_timestamp = RLCRtime()
    RLCR_time = datetime.fromtimestamp(RLCR_timestamp/1000).replace(microsecond=0)
    delta_RLCR = RLCR_time - set_time

    inner_ok = (0<=delta_RRCR.total_seconds()<=1 and 0<=delta_RLCR.total_seconds()<=1)
    inner_res = "PASS" if inner_ok else "FAIL"
    fail_msg = f"右角雷达时间={RRCR_time}s，左角雷达时间={RLCR_time}s,同步时间={set_time}"if not inner_ok else "-"

    add_test_record(
        case_name="TC_Timesync_01_013_角雷达",
        set_time=None,
        rtc=None,
        soc=None,
        mcu=None,
        mgmt=None,
        inner_res=inner_res,
        icc_res="-",
        inner_err=fail_msg,
        icc_err="-",
        icc_flag="-"
    )
    print(RRCR_time)
    stop_can_nm()


def test_case_16():
    print("---------------TC_Timesync_01_016---------------------")
    print("未发送ICC_COM_8报文，以RTC作为时间源同步")

    client, transport = ssh_connect()
    try:
        rtc = get_rtc_time(client)
        mcu = get_mcu_time(client)
        soc = get_soc_time(client)
        Management = get_Management_time(client)
        result("TC_Timesync_01_016",1, soc, mcu, rtc, Management,None,check_icc=False)
    finally:
        transport.close()

def test_case_17():
    print("---------------TC_Timesync_01_017---------------------")
    print("发送ICC_COM_8报文，早于当前系统时间，则继续以RTC作为时间源同步")
    rtc,mcu,soc,Management = sync_reboot(0)
    set_time_str = canoetime()
    set_time = datetime.strptime(set_time_str, "%Y-%m-%d_%H:%M:%S")
    result("TC_Timesync_01_017",1,soc,mcu,rtc,Management,set_time,check_icc=True)
    set_time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    set_time = datetime.strptime(set_time_str, "%Y-%m-%d %H:%M:%S") - timedelta(seconds=5)
    rtc,mcu,soc,Management = sync_reboot(set_time)
    result("TC_Timesync_01_017",1,soc,mcu,rtc,Management,set_time,check_icc=True)
    
def test_case_18():
    print("---------------TC_Timesync_01_018---------------------")
    print("发送ICC_COM_8报文，晚当前系统时间2s，则以ICC作为时间源同步")
    rtc,mcu,soc,Management = sync_reboot(0)
    set_time_str = canoetime()
    set_time = datetime.strptime(set_time_str, "%Y-%m-%d_%H:%M:%S")
    result("TC_Timesync_01_018",1,soc,mcu,rtc,Management,set_time,check_icc=True)

    set_time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    set_time = datetime.strptime(set_time_str, "%Y-%m-%d %H:%M:%S") + timedelta(seconds=2)
    rtc,mcu,soc,Management = sync_reboot(set_time)
    result("TC_Timesync_01_018",0,soc,mcu,rtc,Management,set_time,check_icc=True)
    
def test_case_19():
    print("---------------TC_Timesync_01_019---------------------")
    print("验证管理面时钟同步偏差")
    client, transport = ssh_connect()
    output = exec_cmd(client, "timedatectl")
    match = re.search(r"System clock synchronized:\s*(\w+)", output)
    if match:
        sync_status = match.group(1).strip()  # 拿到 yes 或 no
        print("时钟同步状态：", sync_status)
    
    inner_ok = (sync_status == "yes")
    inner_res = "PASS" if inner_ok else "FAIL"
    fail_msg = "系统时钟未同步"if not inner_ok else "-"

    add_test_record(
        case_name="TC_Timesync_01_019",
        set_time=None,
        rtc=None,
        soc=None,
        mcu=None,
        mgmt=None,
        inner_res=inner_res,
        icc_res="-",
        inner_err=fail_msg,
        icc_err="-",
        icc_flag="-"
    )
    transport.close()

def test_case_20():
    print("---------------TC_Timesync_01_020---------------------")
    print("管理面时钟同步运行稳定性测试")
    rtc,mcu,soc,Management = sync_reboot(0)
    set_time_str = canoetime()
    set_time = datetime.strptime(set_time_str, "%Y-%m-%d_%H:%M:%S")
    result("TC_Timesync_01_020_首次同步",1,soc,mcu,rtc,Management,set_time,check_icc=True)  
    print("等待十分钟")
    time.sleep(600)
    set_time_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    time_now = datetime.strptime(set_time_now, "%Y-%m-%d %H:%M:%S")
    check_time = time_now + timedelta(seconds=5)
    delta_time = check_time - set_time
    delta_sec = delta_time.total_seconds()

    client, transport = ssh_connect()
    try:
        rtc = get_rtc_time(client)
        mcu = get_mcu_time(client)
        soc = get_soc_time(client)
        Management = get_Management_time(client)
    finally:
        transport.close()

    print(delta_time.total_seconds())
    if 599 <= delta_sec <= 601:
        inner_res = "PASS"
        fail_msg = "时间流逝正常无跳变"
        print("时间流逝正常无跳变")
    else:
        inner_res = "FAIL"
        # 失败显示原始时间，无差值，HTML换行
        fail_msg = f"时间有跳变<br>同步时间：{set_time.strftime('%Y-%m-%d %H:%M:%S')}<br>等待10分钟后时间：{check_time.strftime('%Y-%m-%d %H:%M:%S')}"
        print(f"时间有跳变,同步时间({set_time}),等待十分钟后查询的时间({check_time})")

    # 写入报告（不校验ICC，所有ICC列显示-）
    add_test_record(
        case_name="TC_Timesync_01_020_10分钟稳定性校验",
        set_time=None,
        rtc=rtc,
        soc=soc,
        mcu=mcu,
        mgmt=Management,
        inner_res=inner_res,
        icc_res="-",
        inner_err=fail_msg,
        icc_err="-",
        icc_flag="-"
    )

def test_case_21():
    print("---------------TC_Timesync_reboot_01_021---------------------")
    print("管理面时间与世界时间同步")
    rtc,mcu,soc,Management = sync_reboot(0)
    set_time_str = canoetime()
    set_time = datetime.strptime(set_time_str, "%Y-%m-%d_%H:%M:%S")
    result("TC_Timesync_01_021",1,soc,mcu,rtc,Management,set_time,check_icc=True) 

if __name__ == "__main__":
    if app.Measurement.Running:
        app.Measurement.Stop()
        time.sleep(2)
    else:
        app.Open(cfg_path)
        print(f"已加载工程：{cfg_path}")
        time.sleep(5)  # 等待加载完成(can工程不能是未保存的状态)
    app.Measurement.Start()
    time.sleep(3)
    test_case_1()
    test_case_2()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_13()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()
    generate_html_report()
    app.Measurement.Stop()