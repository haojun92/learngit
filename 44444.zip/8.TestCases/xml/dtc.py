import pandas as pd


def generate_capl_testcases_simple(file_path, output_file):
    """
    使用固定模板生成CAPL测试用例，支持自定义排序
    """
    try:
        # 读取Excel文件
        df = pd.read_excel(file_path,dtype=str)

        # 查找列（不区分大小写）
        col_mapping = {
            'messageid': None,
            'expdtcidh': None,
            'expdtcidm': None,
            'expdtcidl': None,
            'timeoutqual': None,
            'timeoutdequal': None,
            'title': None,
            'signalmessagename': None,
            'buschannel': None,
            'cycletime': None,
        }

        for col in df.columns:
            col_str = str(col).lower().strip()
            if col_str in col_mapping:
                col_mapping[col_str] = col

        # 检查必要的列是否存在
        required_cols = ['title', 'messageid', 'signalmessagename', 'expdtcidh', 'expdtcidm', 'expdtcidl', 'timeoutqual', 'timeoutdequal','buschannel','cycletime']
        for req_col in required_cols:
            if col_mapping[req_col] is None:
                print(f"错误: 找不到 '{req_col}' 列")
                return False

        # 自定义排序顺序
        # 可以在这里修改排序优先级，数字越小优先级越高
        custom_sort_order = {
            'Communication': 1,  # 第一优先级
            'RollingCounter': 2,  # 第二优先级
            'CRC': 3  # 第三优先级
        }

        # 按title分组数据
        title_col = col_mapping['title']
        grouped = df.groupby(df[title_col])

        # 生成测试用例
        testgroups_xml = []

        # 创建分组列表，并添加排序权重
        sorted_groups = []
        for title, group in grouped:
            # 获取排序权重，如果没有定义则放在最后（使用大数字）
            sort_weight = custom_sort_order.get(title,999)
            sorted_groups.append((sort_weight, title, group))

        # 按权重排序
        sorted_groups.sort(key=lambda x: x[0])

        # 处理每个分组（按排序后的顺序）
        for sort_weight, title, group in sorted_groups:
            testcases_xml = []
            testcase_id = 0

            for idx, row in group.iterrows():
                testcase_id += 1

                if title == 'Communication':
                    testcase = f'''\t\t<capltestcase name="DTC_Common" title="TC_CommunicationDTC_01_{testcase_id:03d}">
\t\t\t<caplparam type="string" name="DTCError">FAULT_CANFD_LostCom</caplparam>
\t\t\t<caplparam type="string" name="BusChannel">{row[col_mapping['buschannel']]}</caplparam>
\t\t\t<caplparam type="string" name="SignalMssageName">{row[col_mapping['signalmessagename']]}</caplparam>
\t\t\t<caplparam type="int" name="expDtcId">0x{row[col_mapping['expdtcidh']]+row[col_mapping['expdtcidm']]+row[col_mapping['expdtcidl']]}</caplparam>
\t\t\t<caplparam type="int" name="timeoutQual">{int(row[col_mapping['timeoutqual']])*int(row[col_mapping['cycletime']])}</caplparam>
\t\t\t<caplparam type="int" name="timeoutDequal">{int(row[col_mapping['timeoutdequal']])*int(row[col_mapping['cycletime']])}</caplparam>
\t\t\t<caplparam type="string" name="Title">FAULT_CANFD_LostCom_{row[col_mapping['signalmessagename']]}_{row[col_mapping['messageid']]}-DTC_Common</caplparam>
\t\t\t<caplparam type="string" name="Purpose">Purpose: Verify that {row[col_mapping['signalmessagename']]}_{row[col_mapping['messageid']]} is lost (0x{row[col_mapping['expdtcidh']]+row[col_mapping['expdtcidm']]+row[col_mapping['expdtcidl']]}) </caplparam>
\t\t\t<caplparam type="string" name="TestCaseID">TC_CommunicationDTC_01_{testcase_id:03d}</caplparam>
\t\t</capltestcase>'''

                elif title == 'RollingCounter':
                    testcase = f'''\t\t<capltestcase name="DTC_Common" title="ST_SQNError_ACU_{row[col_mapping['mssageid']]}_{testcase_id:03d}">
\t\t\t<caplparam type="string" name="DTCError">FAULT_CANFD_LostCom</caplparam>
\t\t\t<caplparam type="string" name="BusChannel">CH</caplparam>
\t\t\t<caplparam type="string" name="MssageID">{row[col_mapping['mssageid']]}</caplparam>
\t\t\t<caplparam type="int" name="expDtcId">{row[col_mapping['expdtcid']]}</caplparam>
\t\t\t<caplparam type="int" name="timeoutQual">{row[col_mapping['timeoutqual']]}</caplparam>
\t\t\t<caplparam type="int" name="timeoutDequal">{row[col_mapping['timeoutdequal']]}</caplparam>
\t\t\t<caplparam type="string" name="Title">FAULT_CH_ACU_1_{row[col_mapping['mssageid']]}_RC_Error - Storage condition</caplparam>
\t\t\t<caplparam type="string" name="Purpose">Purpose: Verify that FAULT_CH_ACU_1_{row[col_mapping['mssageid']]}_RC_Error ({row[col_mapping['expdtcid']]}) is not set when the storage conditions for the DTC are not met.</caplparam>
\t\t\t<caplparam type="string" name="TestCaseID">ST_SQNError_ACU_{row[col_mapping['mssageid']]}_{testcase_id:03d}</caplparam>
\t\t</capltestcase>'''

                elif title == 'CRC':
                    testcase = f'''\t\t<capltestcase name="DTC_Common" title="ST_CRCError_ACU_{row[col_mapping['mssageid']]}_{testcase_id:03d}">
\t\t\t<caplparam type="string" name="DTCError">FAULT_CANFD_LostCom</caplparam>
\t\t\t<caplparam type="string" name="BusChannel">CH</caplparam>
\t\t\t<caplparam type="string" name="MssageID">{row[col_mapping['mssageid']]}</caplparam>
\t\t\t<caplparam type="int" name="expDtcId">{row[col_mapping['expdtcid']]}</caplparam>
\t\t\t<caplparam type="int" name="timeoutQual">{row[col_mapping['timeoutqual']]}</caplparam>
\t\t\t<caplparam type="int" name="timeoutDequal">{row[col_mapping['timeoutdequal']]}</caplparam>
\t\t\t<caplparam type="string" name="Title">FAULT_CH_ACU_{row[col_mapping['mssageid']]}_CRC_Error - DTC_Common</caplparam>
\t\t\t<caplparam type="string" name="Purpose">Purpose: Verify that FAULT_CH_ACU_{row[col_mapping['mssageid']]}_CRC_Error is not set when the storage conditions for the DTC are not met.</caplparam>
\t\t\t<caplparam type="string" name="TestCaseID">ST_CRCError_ACU_{row[col_mapping['mssageid']]}_{testcase_id:03d}</caplparam>
\t\t</capltestcase>'''

                else:
                    # 处理未定义的title类型
                    print(f"警告: 发现未定义的title类型 '{title}'，跳过此记录")
                    continue

                testcases_xml.append(testcase)

            # 为每个分组创建一个testgroup
            if testcases_xml:
                testgroup_xml = f'\n\t<testgroup title="{title}">\n'
                testgroup_xml += '\n'.join(testcases_xml)
                testgroup_xml += '\n\t</testgroup>'
                testgroups_xml.append(testgroup_xml)

        # 组合成完整XML
        full_xml = '<?xml version="1.0" encoding="iso-8859-1" standalone="yes"?>\n'
        full_xml += '<testmodule title="DTC" version="1.0">\n'
        full_xml += '\n'.join(testgroups_xml)
        full_xml += '\n</testmodule>'

        # 保存文件
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(full_xml)

        # 输出统计信息
        print(f"共生成 {len(df)} 个测试用例到 {output_file}")
        print(f"共创建了 {len(testgroups_xml)} 个testgroup")
        print("=" * 50)
        # 显示排序结果
        print("XML文件中的各testgroup的测试用例数量:")
        for i, (sort_weight, title, group) in enumerate(sorted_groups, 1):
            print(f"  {i}. {title} ( {len(group)} 个测试用例)")

        return True

    except Exception as e:
        print(f"错误: {e}")
        import traceback
        traceback.print_exc()
        return False


# 主程序
if __name__ == "__main__":
    # Excel文件路径
    excel_file = "D:/work/DTC.xlsx"  # 请修改为你的Excel文件路径

    # 生成CAPL测试用例
    print("\n生成CAPL测试用例...")

    # 生成XML文件
    success = generate_capl_testcases_simple(
        file_path=excel_file,
        output_file="../Communication-DTC.xml"
    )

    if success:
        print("\n成功生成XML文件")
    else:
        print("\n生成失败，请检查Excel文件格式。")