# -*- coding: utf-8 -*-
import sys
import xml.etree.ElementTree as ET
import os
from datetime import datetime
import time

def convert():
    if len(sys.argv) > 1:
        xml_input_path = os.path.abspath(sys.argv[1])
    else:
        print("❌ Error: No XML path provided.")
        return
    max_wait = 15
    start_time = time.time()
    print(f"[*] 正在监控 XML 存盘状态...")
    while time.time() - start_time < max_wait:
        sys.stdout.write(f"\r[*] 等待报告生成中... 剩余 {max_wait - int(time.time() - start_time):2d} 秒 ")
        sys.stdout.flush()
        try:
            if os.path.exists(xml_input_path):
                with open(xml_input_path, 'r', encoding='utf-8') as f:
                    # 检查 XML 里是否已经写进了收尾 Case 的名字
                    if "Tc_Smoke_Visual" in f.read():
                        break
        except: pass
        time.sleep(1)
    # 给系统留一点文件写入的时间缓冲
    # time.sleep(5.0)
    if not os.path.exists(xml_input_path):
        print(f"❌ File not found -> {xml_input_path}")
        return

    try:
        parser = ET.XMLParser(encoding="utf-8")
        tree = ET.parse(xml_input_path, parser=parser)
        root = tree.getroot()
    except Exception as e:
        print(f"❌ Error parsing XML: {e}")
        return
    
    base_file_name = os.path.basename(xml_input_path) 
    output_filename = base_file_name.replace("report", "Visual").replace(".xml", ".html")
    output_dir = os.path.dirname(xml_input_path)
    final_html_path = os.path.join(output_dir, output_filename)

    # 24 项清单 (保持不变)
    FINAL_LIST = [
        "[TC_Smoke_001] DA_CAN报文发送周期验证", "[TC_Smoke_002] DA_CAN信号验证_CRC",
        "[TC_Smoke_003] DA_CAN信号验证_RC", "[TC_Smoke_004] DA_CAN时间同步周期验证",
        "[TC_Smoke_005] DA_CAN时间同步信号验证_CRC", "[TC_Smoke_006] DA_CAN时间同步信号验证_RC",
        "[TC_Smoke_007] 车身CH_CAN报文发送周期验证", "[TC_Smoke_008] 车身CH_CAN信号验证_CRC",
        "[TC_Smoke_009] 车身CH_CAN信号验证_RC", "[TC_Smoke_010] ssh连接域控验证",
        "[TC_Smoke_011] KL15唤醒校验", "[TC_Smoke_012] ota_version",
        "[TC_Smoke_013] soc_version", "[TC_Smoke_014] mcu_version",
        "[TC_Smoke_015] bsp_version", "[TC_Smoke_016] 核心管理进程_AutonomyModule",
        "[TC_Smoke_017] 诊断管理监控_DiagManageModule", "[TC_Smoke_018] 诊断应用监控_DiagAppModule",
        "[TC_Smoke_019] OTA服务监控_OTAService", "[TC_Smoke_020] 故障管理监控_FaultManager",
        "[TC_Smoke_021] MCU到SOC车端BLF回灌验证", "[TC_Smoke_022] SOC到MCU端控制指令验证",
        "[TC_Smoke_023] 模拟节点回灌_修改车速值验证", "[TC_Smoke_024] 模拟节点回灌_修改车递有效位验证"
    ]

    # 初始化为特殊字符，用于判断是否是第一次赋值
    extracted_results = {name: "INIT" for name in FINAL_LIST}
    report_ver = "Unknown Version"

    # 核心逻辑：一票否决权
    def update_res(key, status):
        # 1. 如果该项已经是 FAIL，锁死，不接受任何更新
        if extracted_results.get(key) == "FAIL":
            return
        # 2. 如果当前状态是 FAIL，或者该项还是初始状态，则更新
        if status == "FAIL" or extracted_results.get(key) == "INIT":
            extracted_results[key] = status

    for step in root.findall(".//teststep"):
        ident_val = (step.get('ident') or "").upper()
        desc_text = (step.text or "").strip().replace('\\n', '')
        xml_result = step.get('result', 'fail').lower()
        text_upper = desc_text.upper()
        
        # 判定当前步骤是否真的通过 (考虑文本中的 FAILED! 关键字)[cite: 5, 8]
        is_error_text = ("FAILED!" in text_upper or "ERR:" in text_upper or "INACTIVE" in text_upper)
        current_status = "PASS" if (xml_result == "pass" and not is_error_text) else "FAIL"

        # A. 报文 ID 匹配 (采用一票否决更新逻辑)[cite: 5, 6, 8]
        if "159" in ident_val or "159" in text_upper:
            if "CYCLE" in text_upper: update_res(FINAL_LIST[0], current_status)
            if "CRC" in text_upper:   update_res(FINAL_LIST[1], current_status)
            if ("ROLLING" in text_upper or "RC" in text_upper): update_res(FINAL_LIST[2], current_status)
            
        if "515" in ident_val or "515" in text_upper:
            if "CYCLE" in text_upper: update_res(FINAL_LIST[3], current_status)
            if "CRC" in text_upper:   update_res(FINAL_LIST[4], current_status)
            if ("ROLLING" in text_upper or "RC" in text_upper): update_res(FINAL_LIST[5], current_status)
            
        if "30F" in ident_val or "30F" in text_upper:
            if "CYCLE" in text_upper: update_res(FINAL_LIST[6], current_status)
            if "CRC" in text_upper:   update_res(FINAL_LIST[7], current_status)
            if ("ROLLING" in text_upper or "RC" in text_upper): update_res(FINAL_LIST[8], current_status)

        # B. 版本与环境
        if "SOC_VERSION:" in text_upper:
            try:
                report_ver = desc_text.split("SOC_Version:")[1].strip()
                update_res("[TC_Smoke_013] soc_version", current_status)
            except: pass
        if "OTA_VERSION:" in text_upper: update_res("[TC_Smoke_012] ota_version", current_status)
        if "BSP_VERSION:" in text_upper: update_res("[TC_Smoke_015] bsp_version", current_status)
        if "MCU_VERSION:" in text_upper: update_res("[TC_Smoke_014] mcu_version", current_status)
        if "SSH_STATUS: CONNECTED" in text_upper: update_res("[TC_Smoke_010] ssh连接域控验证", current_status)
        if "KL15" in text_upper and "ACTIVE" in text_upper: update_res("[TC_Smoke_011] KL15唤醒校验", current_status)

        # C. 进程监控与回灌验证
        if "AUTONOMY" in text_upper: update_res("[TC_Smoke_016] 核心管理进程_AutonomyModule", current_status)
        if "DIAG_MANAGER" in text_upper: update_res("[TC_Smoke_017] 诊断管理监控_DiagManageModule", current_status)
        if "DIAG_APP" in text_upper: update_res("[TC_Smoke_018] 诊断应用监控_DiagAppModule", current_status)
        if "OTA_SERVICE" in text_upper: update_res("[TC_Smoke_019] OTA服务监控_OTAService", current_status)
        if "FAULT_MANAGER" in text_upper: update_res("[TC_Smoke_020] 故障管理监控_FaultManager", current_status)
        if "STEERING_ANGLE" in text_upper: update_res("[TC_Smoke_021] MCU到SOC车端BLF回灌验证", current_status)
        if "SPEED_MPS" in text_upper: update_res("[TC_Smoke_023] 模拟节点回灌_修改车速值验证", current_status)
        if "SPEED_VALID" in text_upper: update_res("[TC_Smoke_024] 模拟节点回灌_修改车递有效位验证", current_status)
        if "ADASCMD" in text_upper or "控制指令" in text_upper: update_res("[TC_Smoke_022] SOC到MCU端控制指令验证", current_status)

    # 最后处理：将所有仍然是 INIT 的项转为 FAIL (防止漏项显示不正常)
    for name in FINAL_LIST:
        if extracted_results[name] == "INIT":
            extracted_results[name] = "FAIL"

    # HTML 生成 (保持不变)
    table_rows = ""
    for i, name in enumerate(FINAL_LIST, 1):
        st = extracted_results[name]
        st_color = "#28a745" if st == "PASS" else "#dc3545"
        table_rows += f"<tr><td class='center-col'>{i}</td><td class='left-col'>{name}</td><td class='center-col' style='color:{st_color}; font-weight:bold;'>{st}</td></tr>"

    html_template = f"""
    <html><head><meta charset="utf-8"><style>
        body {{ font-family: 'Segoe UI', Arial, sans-serif; padding: 40px; background: #f4f7f6; }}
        .container {{ background: white; max-width: 900px; margin: auto; padding: 30px; border-radius: 8px; border: 1px solid #ddd; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }}
        .header {{ text-align: center; font-size: 22px; font-weight: bold; margin-bottom: 25px; color: #333; }}
        table {{ width: 100%; border-collapse: collapse; border: 1px solid #ccc; }}
        th {{ background: #004085; color: white; padding: 12px; font-size: 15px; border: 1px solid #ccc; }}
        td {{ border: 1px solid #ccc; padding: 10px; font-size: 14px; color: #333; }}
        .center-col {{ text-align: center; }}
        .left-col {{ text-align: left; padding-left: 15px; }}
        tr:nth-child(even) {{ background: #f9f9f9; }}
        tr:hover {{ background: #e9ecef; }}
    </style></head>
    <body><div class="container">
        <div class="header">Smoke Test Version : {report_ver}</div>
        <table><thead><tr><th width="8%">No.</th><th width="72%" class="left-col">Test Item Name</th><th width="20%">Status</th></tr></thead>
        <tbody>{table_rows}</tbody></table>
        <div style="text-align:right; margin-top:20px; color:#666; font-size:12px;">Visual Report Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</div>
    </div></body></html>
    """

    with open(final_html_path, "w", encoding="utf-8") as f:
        f.write(html_template)
    
    print(f"✅ Success: Visual Report generated at {final_html_path}")

if __name__ == "__main__":
    convert()