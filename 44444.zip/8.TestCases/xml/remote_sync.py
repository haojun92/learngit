# -*- coding: utf-8 -*-
import paramiko
import os
import sys
import time
import threading


# ==================================================
# 1. 配置信息
# ==================================================
CONFIG = {
    "host": "10.113.135.63",
    "user": "dazhuo",
    "pw": "dazhuo",
    "remote_path": "/home/dazhuo/smoke_test",
    "remote_file": "versions.txt",
    "local_file": "versions.txt",
    # --- 按照要求更新执行指令 ---
    "pytest_cmd": "python3 -u -m pytest", 
    "local_log_root": r"D:\LogFiles"
}

def countdown_timer(duration, stop_event):
    """在终端原地刷新显示倒计时"""
    start_time = time.time()
    while not stop_event.is_set():
        elapsed = time.time() - start_time
        remaining = max(0, duration - int(elapsed))
        sys.stdout.write(f"\r[*] 远程任务执行中... 预计剩余: {remaining:2d}s (实时无缓冲监控) ")
        sys.stdout.flush()
        if remaining <= 0:
            sys.stdout.write("\r[*] 采样倒计时结束，正在收尾并准备同步数据...          \n")
            sys.stdout.flush()
            break
        time.sleep(1)

def run():
    if not os.path.exists(CONFIG["local_log_root"]):
        os.makedirs(CONFIG["local_log_root"])

    base_dir = os.path.dirname(os.path.abspath(__file__))
    local_version_path = os.path.join(base_dir, CONFIG["local_file"])
    files_to_upload = ["test_bench_smoke.py", "conftest.py"]

    print(f"[{time.strftime('%H:%M:%S')}] --- 自动化同步任务启动 ---")

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        ssh.connect(CONFIG['host'], username=CONFIG['user'], password=CONFIG['pw'], timeout=15)
        print("[OK] SSH 连接成功")

        ssh.exec_command(f"mkdir -p {CONFIG['remote_path']}")
        sftp = ssh.open_sftp()

        for fname in files_to_upload:
            full_local_file = os.path.join(base_dir, fname)
            if os.path.exists(full_local_file):
                print(f"[*] 同步脚本: {fname}")
                sftp.put(full_local_file, f"{CONFIG['remote_path']}/{fname}")

        # --- 按照大哥要求修改的远程执行指令 ---
        remote_cmd = (
            f"export CRYPTOGRAPHY_OPENSSL_NO_LEGACY=1 && "
            f"cd {CONFIG['remote_path']} && "
            f"{CONFIG['pytest_cmd']} test_bench_smoke.py --env=real -s"
        )
        
        print(f"[*] 指令已发送: {CONFIG['pytest_cmd']} ...")
        
        stop_timer = threading.Event()
        timer_thread = threading.Thread(target=countdown_timer, args=(45, stop_timer))
        timer_thread.start()

        # 执行命令
        stdin, stdout, stderr = ssh.exec_command(remote_cmd)
        
        # 实时打印远程输出 (配合 python3 -u 参数)
        for line in iter(stdout.readline, ""):
            if line:
                # 另起一行打印，避免干扰倒计时
                sys.stdout.write(f"\n[Remote] {line.strip()}")
                sys.stdout.flush()

        exit_status = stdout.channel.recv_exit_status()
        stop_timer.set()
        timer_thread.join()
        print(f"\n[OK] 远程指令执行完毕 (Status: {exit_status})")

        # --- 下载回传与清理 ---
        remote_version_p = f"{CONFIG['remote_path']}/{CONFIG['remote_file']}"
        time.sleep(2)
        sftp.get(remote_version_p, local_version_path)
        print(f"[OK] 报告同步成功: {local_version_path}")

        files = sftp.listdir(CONFIG['remote_path'])
        log_files = [f for f in files if f.startswith("chassis_") and f.endswith(".log")]

        for log_f in log_files:
            remote_log_p = f"{CONFIG['remote_path']}/{log_f}"
            local_log_p = os.path.join(CONFIG["local_log_root"], log_f)
            print(f"[*] 发现日志: {log_f} -> 正在同步至 D:\\LogFiles...")
            sftp.get(remote_log_p, local_log_p)
            
            if os.path.exists(local_log_p) and os.path.getsize(local_log_p) > 0:
                print(f"[OK] {log_f} 传输完成，清理跳板机文件...")
                sftp.remove(remote_log_p)

        sftp.close()

    except Exception as e:
        print(f"\n[!] 运行异常: {str(e)}")
    finally:
        ssh.close()
        time.sleep(2)
        # --- 新增：创建完工标志位，通知 CAPL ---
        local_flag = os.path.join(base_dir, "done.flag")
        with open(local_flag, "w") as f:
            f.write("done")
        print(f"[{time.strftime('%H:%M:%S')}] --- 全部任务彻底结束 (done.flag已生成) ---")

if __name__ == "__main__":
    run()
