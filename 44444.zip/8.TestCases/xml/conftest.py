# -*- coding: utf-8 -*-
import os
import pytest
import paramiko

# 环境变量：解决 OpenSSL 3.0 报错
os.environ["CRYPTOGRAPHY_OPENSSL_NO_LEGACY"] = "1"

def pytest_addoption(parser):
    parser.addoption("--env", action="store", default="sim", help="real/sim")

@pytest.fixture(scope="session")
def env_mode(pytestconfig):
    return pytestconfig.getoption("--env")

@pytest.fixture(scope="session")
def ssh_client(env_mode):
    """管理 10.43.0.28 的 SSH 连接 (兼容老版本 Python)"""
    if env_mode == "real":
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        try:
            # 兼容修改：使用 .format() 代替 f-string
            print("\n[SSH] 正在以 root 身份连接 10.43.0.28...")
            ssh.connect(
                "10.43.0.28", 
                username="root", 
                password="", 
                timeout=10, 
                look_for_keys=False,
                allow_agent=False
            )
            yield ssh
            ssh.close()
        except Exception as e:
            pytest.fail("SSH 连接失败: {}".format(e))
    else:
        yield None