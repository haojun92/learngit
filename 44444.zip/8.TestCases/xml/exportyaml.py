import yaml
import subprocess
import os
import paramiko

def extract_specific_data(yaml_file_path, txt_file_path, keys_to_extract):
    """
    从YAML文件中提取特定键的数据并写入TXT
    参数:
        yaml_file_path: YAML文件路径
        txt_file_path: TXT文件路径
        keys_to_extract: 要提取的键列表
    """
    try:
        with open(yaml_file_path, 'r', encoding='utf-8', errors='ignore') as yaml_file:
            data = yaml.safe_load(yaml_file)
        
        with open(txt_file_path, 'w', encoding='utf-8') as txt_file:
            for key in keys_to_extract:
                if key in data:
                    txt_file.write(f"{key}: {data[key]}\n")
                else:
                    txt_file.write(f"{key}: 未找到\n")
        
        print(f"成功提取数据并写入到 {txt_file_path}")
        
    except Exception as e:
        print(f"错误: {e}")

if __name__ == "__main__":
    yaml_file = 'ecu_info.yaml' 
    txt_file = 'ecu_info.txt'  

    base_dir = os.path.dirname(os.path.abspath(__file__))
    localyaml_path = os.path.join(base_dir,yaml_file);
    localtxt_path = os.path.join(base_dir,txt_file);
    print(localyaml_path)

    if os.path.exists(yaml_file):
        os.remove(yaml_file)
        print("文件删除成功！")
    if os.path.exists(txt_file):
        os.remove(txt_file)
        print("文件删除成功！")
        
    #初次上电或断电重启需要先ssh上板子
    transport = paramiko.Transport(('10.43.0.28', 22))
    transport.connect(username='root', password='')

    client = paramiko.SSHClient()
    client._transport = transport
    transport.close()

    # 执行scp命令从远程服务器复制文件到当前目录
    result=subprocess.run(['scp','root@10.43.0.28:/userdata/ecu_info.yaml','./'], capture_output=True, text=True)
    # 检查执行结果
    if result.returncode == 0:
        print("文件复制成功！")
        print("输出:", result.stdout)
        extract_specific_data(yaml_file, txt_file, 
                         ['Vehicle_platform', 'vehicle_vin', 'ecu_hardward_ver', 'boot_software_ver','ecu_software_ver'])
    else:
        print("文件复制失败！")
        print("错误信息:", result.stderr)

