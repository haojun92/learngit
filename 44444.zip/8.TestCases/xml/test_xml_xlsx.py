import xml.etree.ElementTree as ET
import pandas as pd


def extract_dtc_data(xml_file, excel_file='dtc_data.xlsx'):
    """
    简单的XML转Excel函数 - 解决中文乱码
    """
    # 解析XML - 使用二进制方式读取并处理编码
    with open(xml_file, 'rb') as f:
        content = f.read()

    # 将编码声明替换为utf-8
    content = content.replace(b'iso-8859-1', b'utf-8')
    content = content.replace(b'ISO-8859-1', b'utf-8')

    # 解析XML
    root = ET.fromstring(content)

    # 存储数据
    data = []

    # 遍历每个testcase
    for testcase in root.findall('.//capltestcase'):
        row = {
            'title': testcase.get('title', ''),
            'DTCError_SignalMssageName': '',
            'DTCNumber': '',
            'MonitorEnableCriteria': '',
            'Title': ''
        }

        # 提取参数
        for param in testcase.findall('caplparam'):
            name = param.get('name', '')
            value = param.text.strip() if param.text else ''

            if name in row:
                if name == 'MonitorEnableCriteria':
                    # 保留换行格式
                    value = value.replace('\n', ' | ')
                row[name] = value

        data.append(row)

    # 创建DataFrame并保存
    df = pd.DataFrame(data)
    df = df[['title', 'DTCNumber', 'DTCError_SignalMssageName', 'MonitorEnableCriteria', 'Title']]

    # 保存到Excel，指定编码
    df.to_excel(excel_file, index=False, engine='openpyxl')
    print(f"成功转换 {len(data)} 条数据到 {excel_file}")
    print("\n预览数据:")
    print(df.head())

    return df


# 使用方法
if __name__ == "__main__":
    df = extract_dtc_data('DTC_invalid_TestCases.xml', 'D:/invalid_output.xlsx')