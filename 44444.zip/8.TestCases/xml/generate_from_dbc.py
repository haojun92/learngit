import os
import re
import cantools

# ===================== 配置项 =====================
DBC_FILE = r"D:/code/thorx/1.DBC/E0X Project ADCC_DA_J6P Message list  V4.10 Draft _202512272154.dbc"
OUTPUT_DIR = "../output"
TEST_NODE = "ADCC_DA_J6P_M32T"
DEFAULT_CYCLE_TOLERANCE = 10

RC_KEYWORDS = ['*RollgCntr*', 'rollingcounter', 'rolling_counter']
CRC_KEYWORDS = ['checksum', 'check_sum', 'crc', 'chksum', 'crc_1', 'crc_2', 'crc_3', 'ads_crc']
# ==================================================

CFG_FILE = os.path.join(OUTPUT_DIR, "generated_cfg.cin")
HOOKS_FILE = os.path.join(OUTPUT_DIR, "generated_hooks.can")


def normalize_sig_name(sig_name: str) -> str:
    return sig_name.lower().replace("-", "_").replace(" ", "_")


def is_checksum_signal(sig_name: str) -> bool:
    name = normalize_sig_name(sig_name)

    crc_patterns = [
        r'(^|_)crc([0-9]+)?(_|$)',
        r'(^|_)checksum([0-9]+)?(_|$)',
        r'(^|_)check_sum([0-9]+)?(_|$)',
        r'(^|_)chksum([0-9]+)?(_|$)',
        r'(^|_)ads_crc([0-9]+)?(_|$)',
    ]
    return any(re.search(p, name) for p in crc_patterns)


def is_rolling_counter_signal(sig_name: str) -> bool:
    name = normalize_sig_name(sig_name)

    # 先排除 CRC，避免误识别
    if is_checksum_signal(name):
        return False

    rc_patterns = [
        r'(^|_)rollgcntr([0-9]+)?(_|$)',          # 适配 RollgCntr
        r'(^|_)rollingcounter([0-9]+)?(_|$)',
        r'(^|_)rolling_counter([0-9]+)?(_|$)',
        r'(^|_)rollingcnt([0-9]+)?(_|$)',
        r'(^|_)alivecounter([0-9]+)?(_|$)',
        r'(^|_)alive_counter([0-9]+)?(_|$)',
        r'(^|_)alivecnt([0-9]+)?(_|$)',
        r'(^|_)msgcounter([0-9]+)?(_|$)',
        r'(^|_)msg_counter([0-9]+)?(_|$)',
        r'(^|_)msgcnt([0-9]+)?(_|$)',
        r'(^|_)sequencecounter([0-9]+)?(_|$)',
        r'(^|_)seqcounter([0-9]+)?(_|$)',
        r'(^|_)counter([0-9]+)?(_|$)',
        r'(^|_)cnt([0-9]+)?(_|$)',
        r'(^|_)rc([0-9]+)?(_|$)',
    ]
    return any(re.search(p, name) for p in rc_patterns)



# 【新增】从 CRC 信号的注释中提取 DataID
def extract_data_id_from_crc_signal(sig):
    if not sig.comment:
        return 0
    match = re.search(r'DataID[:=\s]+0x([0-9A-Fa-f]+)', sig.comment, re.IGNORECASE)
    return int(match.group(1), 16) if match else 0


def can_fd_len_to_dlc(length: int) -> int:
    length = int(length)
    if 0 <= length <= 8:
        return length
    elif length == 12:
        return 9
    elif length == 16:
        return 10
    elif length == 20:
        return 11
    elif length == 24:
        return 12
    elif length == 32:
        return 13
    elif length == 48:
        return 14
    elif length == 64:
        return 15
    else:
        return 8


def escape_str(s: str) -> str:
    if not s:
        return ""
    return s.replace("\\", "\\\\").replace('"', '\\"')


def is_reserved_signal(sig_name: str) -> int:
    name = sig_name.lower()
    return 1 if ("res" in name or "reserved" in name or "unused" in name) else 0


def collect_tx_messages(db, test_node):
    tx_messages = []
    for msg in db.messages:
        if test_node in msg.senders:
            tx_messages.append(msg)
    return tx_messages


def build_signal_table(tx_messages):
    all_signals = []
    sig_idx = 0
    for msg_idx, msg in enumerate(tx_messages):
        for sig in msg.signals:
            if sig.byte_order == "big_endian":
                start_bit = sig.start
                byte_order = 1
            else:
                start_bit = sig.start
                byte_order = 0

            all_signals.append({
                "sig_idx": sig_idx,
                "msg_idx": msg_idx,
                "msg_name": msg.name,
                "msg_id": msg.frame_id,
                "name": sig.name,
                "start": start_bit,
                "length": sig.length,
                "byte_order": byte_order,
                "is_reserved": is_reserved_signal(sig.name),
                "is_signed": 1 if sig.is_signed else 0,
                "factor": sig.scale if sig.scale is not None else 1,
                "offset": sig.offset if sig.offset is not None else 0,
                "minimum": sig.minimum,
                "maximum": sig.maximum,
                "unit": sig.unit or "",
                "choices": sig.choices or {}
            })
            sig_idx += 1
    return all_signals


# def is_rolling_counter_signal(sig_name: str) -> bool:
#     name_lower = sig_name.lower()
#     return any(kw in name_lower for kw in RC_KEYWORDS)
#
#
# def is_checksum_signal(sig_name: str) -> bool:
#     name_lower = sig_name.lower()
#     return any(kw in name_lower for kw in CRC_KEYWORDS)


def get_rc_max(sig) -> int:
    if sig.maximum is not None:
        return int(sig.maximum)
    if sig.choices:
        return max(sig.choices.keys())
    return 15


def guess_crc_type(msg):
    if msg.frame_id == 0x515:
        return 1
    return 0


# 【优化】支持单报文多组 RC/CRC + 从CRC信号注释取DataID + 补全所有CAPL参数
# def collect_rc_crc_messages(db, test_node):
#     results = []
#     for msg in db.messages:
#         if test_node not in msg.senders:
#             continue
#
#         rc_list = []
#         crc_list = []
#         for sig in msg.signals:
#             if is_rolling_counter_signal(sig.name):
#                 rc_list.append(sig)
#             if is_checksum_signal(sig.name):
#                 crc_list.append(sig)
#
#         # 多组配对
#         group_count = min(len(rc_list), len(crc_list))
#         for i in range(group_count):
#             rc_sig = rc_list[i]
#             crc_sig = crc_list[i]
#
#             rc_max = get_rc_max(rc_sig)
#             crc_type = guess_crc_type(msg)
#             data_id = extract_data_id_from_crc_signal(crc_sig)
#
#             # RC 信息
#             rc_start_bit = rc_sig.start
#             rc_length = rc_sig.length
#             rc_byte_pos = rc_start_bit // 8
#
#             # CRC 信息
#             crc_start_bit = crc_sig.start
#             crc_length = crc_sig.length
#             crc_byte_pos = crc_start_bit // 8
#             msg_len = msg.length
#
#             results.append({
#                 'msg_id': msg.frame_id,
#                 'msg_name': msg.name,
#                 'group_num': i,
#                 'rc_signal_name': rc_sig.name,
#                 'crc_signal_name': crc_sig.name,
#                 'crc_type': crc_type,
#                 'data_id': data_id,
#                 'rc_max': rc_max,
#                 'rc_start_bit': rc_start_bit,
#                 'rc_length': rc_length,
#                 'rc_byte_pos': rc_byte_pos,
#                 'crc_start_bit': crc_start_bit,
#                 'crc_length': crc_length,
#                 'crc_byte_pos': crc_byte_pos,
#                 'msg_len': msg_len,
#                 'crc_profile': crc_type
#             })
#     return results
# def collect_rc_crc_messages(db, test_node):
#     results = []
#     for msg in db.messages:
#         if test_node not in msg.senders:
#             continue
#
#         rc_list = []
#         crc_list = []
#         for sig in msg.signals:
#             if is_rolling_counter_signal(sig.name):
#                 rc_list.append(sig)
#             if is_checksum_signal(sig.name):
#                 crc_list.append(sig)
#
#         rc_list = sorted(rc_list, key=lambda s: s.start)
#         crc_list = sorted(crc_list, key=lambda s: s.start)
#
#         group_count = min(len(rc_list), len(crc_list))
#         for i in range(group_count):
#             rc_sig = rc_list[i]
#             crc_sig = crc_list[i]
#
#             rc_max = get_rc_max(rc_sig)
#             crc_type = guess_crc_type(msg)
#             data_id = extract_data_id_from_crc_signal(crc_sig)
#
#             rc_start_bit = rc_sig.start
#             rc_length = rc_sig.length
#             rc_byte_pos = rc_start_bit // 8
#
#             crc_start_bit = crc_sig.start
#             crc_length = crc_sig.length
#             crc_byte_pos = crc_start_bit // 8
#             msg_len = msg.length
#
#             results.append({
#                 'msg_id': msg.frame_id,
#                 'msg_name': msg.name,
#                 'group_num': i,
#                 'rc_signal_name': rc_sig.name,
#                 'crc_signal_name': crc_sig.name,
#                 'crc_type': crc_type,
#                 'data_id': data_id,
#                 'rc_max': rc_max,
#                 'rc_start_bit': rc_start_bit,
#                 'rc_length': rc_length,
#                 'rc_byte_pos': rc_byte_pos,
#                 'crc_start_bit': crc_start_bit,
#                 'crc_length': crc_length,
#                 'crc_byte_pos': crc_byte_pos,
#                 'msg_len': msg_len,
#                 'crc_profile': crc_type
#             })
#     return results

def collect_rc_crc_messages(db, test_node, sig_index_map):
    results = []
    msg_idx_counter = -1

    for msg in db.messages:
        if test_node not in msg.senders:
            continue

        msg_idx_counter += 1

        rc_list = []
        crc_list = []
        for sig in msg.signals:
            if is_rolling_counter_signal(sig.name):
                rc_list.append(sig)
            if is_checksum_signal(sig.name):
                crc_list.append(sig)

        rc_list = sorted(rc_list, key=lambda s: s.start)
        crc_list = sorted(crc_list, key=lambda s: s.start)

        # 特殊处理：0x515 没有 RC，只保留 CRC
        if msg.frame_id == 0x515:
            rc_list = []

        # 确定配对数量：如果没有 RC，则每个 CRC 生成一个独立实例（rc 部分为 -1）
        if not rc_list:
            # 只有 CRC，没有 RC
            for i, crc_sig in enumerate(crc_list):
                crc_type = guess_crc_type(msg)
                data_id = extract_data_id_from_crc_signal(crc_sig)

                crc_start_bit = crc_sig.start
                crc_length = crc_sig.length
                crc_byte_pos = crc_start_bit // 8
                msg_len = msg.length

                crc_sig_info = sig_index_map.get((msg.frame_id, crc_sig.name))
                crc_sig_idx = crc_sig_info["sig_idx"] if crc_sig_info else -1

                results.append({
                    'msg_id': msg.frame_id,
                    'msg_name': msg.name,
                    'msg_idx': msg_idx_counter,
                    'group_num': i,
                    'rc_signal_name': '',
                    'crc_signal_name': crc_sig.name,
                    'rc_sig_idx': -1,
                    'crc_sig_idx': crc_sig_idx,
                    'crc_type': crc_type,
                    'data_id': data_id,
                    'rc_max': 0,
                    'rc_start_bit': 0,
                    'rc_length': 0,
                    'rc_byte_pos': 0,
                    'crc_start_bit': crc_start_bit,
                    'crc_length': crc_length,
                    'crc_byte_pos': crc_byte_pos,
                    'msg_len': msg_len,
                    'crc_profile': crc_type
                })
        else:
            # 原有 RC+CRC 配对逻辑
            group_count = min(len(rc_list), len(crc_list))
            for i in range(group_count):
                rc_sig = rc_list[i]
                crc_sig = crc_list[i]

                rc_max = get_rc_max(rc_sig)
                crc_type = guess_crc_type(msg)
                data_id = extract_data_id_from_crc_signal(crc_sig)

                rc_start_bit = rc_sig.start
                rc_length = rc_sig.length
                rc_byte_pos = rc_start_bit // 8

                crc_start_bit = crc_sig.start
                crc_length = crc_sig.length
                crc_byte_pos = crc_start_bit // 8
                msg_len = msg.length

                rc_sig_info = sig_index_map.get((msg.frame_id, rc_sig.name))
                crc_sig_info = sig_index_map.get((msg.frame_id, crc_sig.name))

                rc_sig_idx = rc_sig_info["sig_idx"] if rc_sig_info else -1
                crc_sig_idx = crc_sig_info["sig_idx"] if crc_sig_info else -1

                results.append({
                    'msg_id': msg.frame_id,
                    'msg_name': msg.name,
                    'msg_idx': msg_idx_counter,
                    'group_num': i,
                    'rc_signal_name': rc_sig.name,
                    'crc_signal_name': crc_sig.name,
                    'rc_sig_idx': rc_sig_idx,
                    'crc_sig_idx': crc_sig_idx,
                    'crc_type': crc_type,
                    'data_id': data_id,
                    'rc_max': rc_max,
                    'rc_start_bit': rc_start_bit,
                    'rc_length': rc_length,
                    'rc_byte_pos': rc_byte_pos,
                    'crc_start_bit': crc_start_bit,
                    'crc_length': crc_length,
                    'crc_byte_pos': crc_byte_pos,
                    'msg_len': msg_len,
                    'crc_profile': crc_type
                })
    return results
# ===================== CFG 文件 =====================
def gen_cfg(tx_messages, all_signals):
    lines = []
    lines.append('/*@!Encoding:936*/')
    lines.append('variables')
    lines.append('{')
    lines.append(f'  const int CFG_MSG_COUNT = {len(tx_messages)};')
    lines.append(f'  const int CFG_SIGNAL_COUNT = {len(all_signals)};')
    lines.append('')

    msg_names = ', '.join(f'"{escape_str(m.name)}"' for m in tx_messages)
    msg_ids = ', '.join(f'0x{m.frame_id:X}' for m in tx_messages)
    msg_expect_dlc = ', '.join(str(can_fd_len_to_dlc(m.length)) for m in tx_messages)
    msg_expect_len = ', '.join(str(m.length) for m in tx_messages)
    msg_cycle = ', '.join(str(m.cycle_time or 0) for m in tx_messages)
    msg_tol = ', '.join(str(DEFAULT_CYCLE_TOLERANCE) for _ in tx_messages)
    msg_is_fd = ', '.join(str(1 if m.is_fd else 0) for m in tx_messages)
    msg_is_ext = ', '.join(str(1 if m.is_extended_frame else 0) for m in tx_messages)

    lines.append(f'  char gCfgMsgName[CFG_MSG_COUNT][128] = {{ {msg_names} }};')
    lines.append(f'  long gCfgMsgId[CFG_MSG_COUNT] = {{ {msg_ids} }};')
    lines.append(f'  int  gCfgExpectDlc[CFG_MSG_COUNT] = {{ {msg_expect_dlc} }};')
    lines.append(f'  int  gCfgExpectLen[CFG_MSG_COUNT] = {{ {msg_expect_len} }};')
    lines.append(f'  long gCfgExpectCycleMs[CFG_MSG_COUNT] = {{ {msg_cycle} }};')
    lines.append(f'  long gCfgCycleToleranceMs[CFG_MSG_COUNT] = {{ {msg_tol} }};')
    lines.append(f'  int  gCfgIsCanFd[CFG_MSG_COUNT] = {{ {msg_is_fd} }};')
    lines.append(f'  int  gCfgIsExtended[CFG_MSG_COUNT] = {{ {msg_is_ext} }};')
    lines.append('  long gLastRecvTimeMulti[CFG_MSG_COUNT][8];')
    lines.append('  long gCycleFailMulti[CFG_MSG_COUNT][8];')
    lines.append('  long gCycleErrorReportedMulti[CFG_MSG_COUNT][8];')
    lines.append('  // 多周期统计数组 [msgIdx][subTypeIdx]')
    lines.append('  long gMultiRecvCount[CFG_MSG_COUNT][8];')
    lines.append('  long gMultiMinCycleMs[CFG_MSG_COUNT][8];')
    lines.append('  long gMultiMaxCycleMs[CFG_MSG_COUNT][8];')
    lines.append('  long gMultiSumCycleMs[CFG_MSG_COUNT][8];')
    lines.append('  long gMultiSampleCount[CFG_MSG_COUNT][8];')
    lines.append('  long gMultiLastRecvTimeMs[CFG_MSG_COUNT][8];')
    lines.append('  long gMultiCycleErrorReported[CFG_MSG_COUNT][8];')

    lines.append('')

    if all_signals:
        sig_msg_idx = ', '.join(str(s["msg_idx"]) for s in all_signals)
        sig_name = ', '.join(f'"{escape_str(s["name"])}"' for s in all_signals)
        sig_start = ', '.join(str(s["start"]) for s in all_signals)
        sig_len = ', '.join(str(s["length"]) for s in all_signals)
        sig_bo = ', '.join(str(s["byte_order"]) for s in all_signals)
        sig_res = ', '.join(str(s["is_reserved"]) for s in all_signals)
        sig_signed = ', '.join(str(s["is_signed"]) for s in all_signals)

        lines.append(f'  int  gCfgSignalMsgIndex[CFG_SIGNAL_COUNT] = {{ {sig_msg_idx} }};')
        lines.append(f'  char gCfgSignalName[CFG_SIGNAL_COUNT][128] = {{ {sig_name} }};')
        lines.append(f'  int  gCfgSignalStartBit[CFG_SIGNAL_COUNT] = {{ {sig_start} }};')
        lines.append(f'  int  gCfgSignalLength[CFG_SIGNAL_COUNT] = {{ {sig_len} }};')
        lines.append(f'  int  gCfgSignalByteOrder[CFG_SIGNAL_COUNT] = {{ {sig_bo} }};')
        lines.append(f'  int  gCfgSignalIsReserved[CFG_SIGNAL_COUNT] = {{ {sig_res} }};')
        lines.append(f'  int  gCfgSignalIsSigned[CFG_SIGNAL_COUNT] = {{ {sig_signed} }};')
        lines.append('')

    lines.extend([
        '  long gLastRecvTimeMs[CFG_MSG_COUNT];',
        '  long gRecvCount[CFG_MSG_COUNT];',
        '  long gDlcFailCount[CFG_MSG_COUNT];',
        '  long gCycleFailCount[CFG_MSG_COUNT];',
        '  long gMinCycleMs[CFG_MSG_COUNT];',
        '  long gMaxCycleMs[CFG_MSG_COUNT];',
        '  long gCycleSumMs[CFG_MSG_COUNT];',
        '  long gCycleSampleCount[CFG_MSG_COUNT];',
        '',
        '  long gDlcErrorReported[CFG_MSG_COUNT];',
        '  long gCycleErrorReported[CFG_MSG_COUNT];',
        '  long gCanFdErrorReported[CFG_MSG_COUNT];',
        '  long gSigByteOrderErrorReported[CFG_MSG_COUNT];',
        '  long gReservedBitError[CFG_MSG_COUNT];',
        '',
        '  long gSignalMonitorHit[CFG_SIGNAL_COUNT];',
        '  long gSignalLastRawValue[CFG_SIGNAL_COUNT];',
        '  long gSignalChangedCount[CFG_SIGNAL_COUNT];',
        '}'])
    return '\n'.join(lines)
# def gen_rc_crc_init(rc_crc_list):
#     lines = []
#     lines.append('void Common_InitRcCrcInstances(void)')
#     lines.append('{')
#     for i, cfg in enumerate(rc_crc_list):
#         lines.append(f'  // {cfg["msg_name"]}')
#         lines.append(f'  gInstances[{i}].targetId   = 0x{cfg["msg_id"]:X};')
#         lines.append(f'  gInstances[{i}].groupNum   = {cfg["group_num"]};')
#         lines.append(f'  gInstances[{i}].crcType    = {cfg["crc_type"]};')
#         lines.append(f'  gInstances[{i}].crcProfile = {cfg["crc_profile"]};')
#         lines.append(f'  gInstances[{i}].msgLen     = {cfg["msg_len"]};')
#         lines.append(f'  gInstances[{i}].rcMax      = {cfg["rc_max"]};')
#         lines.append(f'  gInstances[{i}].rcBytePos  = {cfg["rc_byte_pos"]};')
#         lines.append(f'  gInstances[{i}].crcBytePos = {cfg["crc_byte_pos"]};')
#         lines.append(f'  gInstances[{i}].rcStartBit = {cfg["rc_start_bit"]};')
#         lines.append(f'  gInstances[{i}].crcStartBit= {cfg["crc_start_bit"]};')
#         lines.append(f'  gInstances[{i}].rcLength   = {cfg["rc_length"]};')
#         lines.append(f'  gInstances[{i}].crcLength  = {cfg["crc_length"]};')
#         lines.append(f'  gInstances[{i}].dataId     = 0x{cfg["data_id"]:04X};')
#         lines.append(f'  strncpy(gInstances[{i}].sigNameRC,  "{cfg["rc_signal_name"]}",  elCount(gInstances[{i}].sigNameRC));')
#         lines.append(f'  strncpy(gInstances[{i}].sigNameCRC, "{cfg["crc_signal_name"]}", elCount(gInstances[{i}].sigNameCRC));')
#         lines.append(f'  strncpy(gInstances[{i}].sigPathRC,  "{cfg["rc_signal_name"]}",  elCount(gInstances[{i}].sigPathRC));')
#         lines.append(f'  strncpy(gInstances[{i}].sigPathCRC, "{cfg["crc_signal_name"]}", elCount(gInstances[{i}].sigPathCRC));')
#         lines.append(f'  gInstances[{i}].frameCount = 0;')
#         lines.append(f'  gInstances[{i}].errCnt_CRC = 0;')
#         lines.append(f'  gInstances[{i}].errCnt_RC  = 0;')
#         lines.append(f'  gInstances[{i}].lastRC     = 0;')
#         lines.append(f'  gInstances[{i}].sameRCCount= 0;')
#         lines.append(f'  gInstances[{i}].isFirstFrame = 1;')
#         lines.append('')
#     lines.append('}')
#     return '\n'.join(lines)
def gen_rc_crc_init(rc_crc_list):
    lines = []
    lines.append('void Common_InitRcCrcInstances(void)')
    lines.append('{')
    lines.append('  int i;')
    lines.append('')
    lines.append('  for (i = 0; i < elCount(gInstances); i++)')
    lines.append('  {')
    lines.append('    gInstances[i].targetId = 0;')
    lines.append('    gInstances[i].msgIdx = -1;')
    lines.append('    gInstances[i].groupNum = 0;')
    lines.append('')
    lines.append('    gInstances[i].rcSigIdx = -1;')
    lines.append('    gInstances[i].crcSigIdx = -1;')
    lines.append('')
    lines.append('    gInstances[i].crcType = 0;')
    lines.append('    gInstances[i].crcProfile = 0;')
    lines.append('    gInstances[i].msgLen = 0;')
    lines.append('    gInstances[i].rcMax = 0;')
    lines.append('')
    lines.append('    gInstances[i].rcBytePos = 0;')
    lines.append('    gInstances[i].crcBytePos = 0;')
    lines.append('    gInstances[i].rcStartBit = 0;')
    lines.append('    gInstances[i].crcStartBit = 0;')
    lines.append('    gInstances[i].rcLength = 0;')
    lines.append('    gInstances[i].crcLength = 0;')
    lines.append('    gInstances[i].crcStartByte = 0;')
    lines.append('    gInstances[i].dataId = 0;')
    lines.append('')
    lines.append('    gInstances[i].sigNameRC[0] = 0;')
    lines.append('    gInstances[i].sigNameCRC[0] = 0;')
    lines.append('    gInstances[i].sigPathRC[0] = 0;')
    lines.append('    gInstances[i].sigPathCRC[0] = 0;')
    lines.append('')
    lines.append('    gInstances[i].frameCount = 0;')
    lines.append('    gInstances[i].errCnt_CRC = 0;')
    lines.append('    gInstances[i].errCnt_RC = 0;')
    lines.append('    gInstances[i].lastRC = 0;')
    lines.append('    gInstances[i].sameRCCount = 0;')
    lines.append('    gInstances[i].isFirstFrame = 1;')
    lines.append('    gInstances[i].lastCalculatedCrc = 0;')
    lines.append('  }')
    lines.append('')
    for i, cfg in enumerate(rc_crc_list):
        lines.append(f'  // {cfg["msg_name"]}')
        lines.append(f'  gInstances[{i}].targetId   = 0x{cfg["msg_id"]:X};')
        lines.append(f'  gInstances[{i}].msgIdx     = {cfg["msg_idx"]};')
        lines.append(f'  gInstances[{i}].groupNum   = {cfg["group_num"]};')
        lines.append(f'  gInstances[{i}].rcSigIdx   = {cfg["rc_sig_idx"]};')
        lines.append(f'  gInstances[{i}].crcSigIdx  = {cfg["crc_sig_idx"]};')
        lines.append(f'  gInstances[{i}].crcType    = {cfg["crc_type"]};')
        lines.append(f'  gInstances[{i}].crcProfile = {cfg["crc_profile"]};')
        lines.append(f'  gInstances[{i}].msgLen     = {cfg["msg_len"]};')
        lines.append(f'  gInstances[{i}].rcMax      = {cfg["rc_max"]};')
        lines.append(f'  gInstances[{i}].rcBytePos  = {cfg["rc_byte_pos"]};')
        lines.append(f'  gInstances[{i}].crcBytePos = {cfg["crc_byte_pos"]};')
        lines.append(f'  gInstances[{i}].rcStartBit = {cfg["rc_start_bit"]};')
        lines.append(f'  gInstances[{i}].crcStartBit= {cfg["crc_start_bit"]};')
        lines.append(f'  gInstances[{i}].rcLength   = {cfg["rc_length"]};')
        lines.append(f'  gInstances[{i}].crcLength  = {cfg["crc_length"]};')
        lines.append(f'  gInstances[{i}].dataId     = 0x{cfg["data_id"]:04X};')
        lines.append(f'  strncpy(gInstances[{i}].sigNameRC,  "{cfg["rc_signal_name"]}",  elCount(gInstances[{i}].sigNameRC));')
        lines.append(f'  strncpy(gInstances[{i}].sigNameCRC, "{cfg["crc_signal_name"]}", elCount(gInstances[{i}].sigNameCRC));')
        lines.append(f'  strncpy(gInstances[{i}].sigPathRC,  "{cfg["rc_signal_name"]}",  elCount(gInstances[{i}].sigPathRC));')
        lines.append(f'  strncpy(gInstances[{i}].sigPathCRC, "{cfg["crc_signal_name"]}", elCount(gInstances[{i}].sigPathCRC));')
        lines.append(f'  gInstances[{i}].frameCount = 0;')
        lines.append(f'  gInstances[{i}].errCnt_CRC = 0;')
        lines.append(f'  gInstances[{i}].errCnt_RC  = 0;')
        lines.append(f'  gInstances[{i}].lastRC     = 0;')
        lines.append(f'  gInstances[{i}].sameRCCount= 0;')
        lines.append(f'  gInstances[{i}].isFirstFrame = 1;')
        lines.append(f'  gInstances[{i}].lastCalculatedCrc = 0;')
        lines.append('')
    lines.append('}')
    return '\n'.join(lines)

def gen_find_rc_crc(rc_crc_list):
    lines = []
    lines.append('int FindRcCrcInstanceIndex(long msgId)')
    lines.append('{')
    for i, cfg in enumerate(rc_crc_list):
        lines.append(f'  if (msgId == 0x{cfg["msg_id"]:X}) return {i};')
    lines.append('  return -1;')
    lines.append('}')
    return '\n'.join(lines)
# ===================== HOOKS 文件 =====================
def gen_hooks(tx_messages, all_signals, rc_crc_list):
    lines = []
    lines.append('/*@!Encoding:936*/')
    lines.append('')

    lines.extend([
        'int Gen_DlcToPayloadLen(int dlc, int isCanFd)',
        '{',
        '  if (isCanFd == 0)',
        '  {',
        '    if (dlc < 0) return 0;',
        '    if (dlc > 8) return 8;',
        '    return dlc;',
        '  }',
        '  switch (dlc)',
        '  {',
        '    case 0: return 0; case 1: return 1; case 2: return 2; case 3: return 3;',
        '    case 4: return 4; case 5: return 5; case 6: return 6; case 7: return 7;',
        '    case 8: return 8; case 9: return 12; case 10: return 16; case 11: return 20;',
        '    case 12: return 24; case 13: return 32; case 14: return 48; case 15: return 64;',
        '    default: return 0;',
        '  }',
        '}',
        ''
    ])

    lines.append('int Gen_FindMsgIndex(long msgId)')
    lines.append('{')
    lines.append('  switch (msgId)')
    lines.append('  {')
    for idx, msg in enumerate(tx_messages):
        lines.append(f'    case 0x{msg.frame_id:X}: return {idx}; // {msg.name}')
    lines.append('    default: return -1;')
    lines.append('  }')
    lines.append('}')
    lines.append('')

    global_sig_idx = 0
    for msg_idx, msg in enumerate(tx_messages):
        lines.append(f'void Gen_MonitorMsg_{msg_idx}(long data[], int payloadLen)')
        lines.append('{')
        lines.append('  long rawVal;')
        lines.append('  int firstHit;')
        if not msg.signals:
            lines.append('  return;')
            lines.append('}')
            lines.append('')
            continue
        for sig in msg.signals:
            if sig.length <= 32:
                lines.append(f'  rawVal = getSignalRawValue(data, payloadLen, {global_sig_idx});')
                lines.append(f'  firstHit = (gSignalMonitorHit[{global_sig_idx}] == 0);')
                lines.append(f'  gSignalMonitorHit[{global_sig_idx}]++;')
                lines.append(f'  if (firstHit) gSignalLastRawValue[{global_sig_idx}] = rawVal;')
                lines.append(f'  else if (gSignalLastRawValue[{global_sig_idx}] != rawVal) {{')
                lines.append(f'    gSignalChangedCount[{global_sig_idx}]++;')
                lines.append(f'    gSignalLastRawValue[{global_sig_idx}] = rawVal;')
                lines.append(f'  }}')
            global_sig_idx += 1
        lines.append('}')
        lines.append('')

    lines.append('void Gen_DispatchSignalMonitor(int idx, long data[], int payloadLen)')
    lines.append('{')
    lines.append('  switch (idx)')
    lines.append('  {')
    for idx, msg in enumerate(tx_messages):
        lines.append(f'    case {idx}: Gen_MonitorMsg_{idx}(data, payloadLen); break;')
    lines.append('    default: break;')
    lines.append('  }')
    lines.append('}')
    lines.append('')

    # 多周期配置
    multi_cycle_msgs = {
        0x515: [
            (480, 0x20, "TimeSync_Fast"),
            (20,  0x28, "TimeSync_Slow")
        ]
    }
    sub_type_map = {0x20: 0, 0x28: 1}  # 定义映射

    # 多周期检查函数
    lines.append('void Common_CheckMultiCycle(long msgId, int msgIdx, byte firstByte, int subTypeIdx, long expectedCycle)')
    lines.append('{')
    lines.append('  long currtime = timeNow() / 100;')
    lines.append('  long diff;')
    lines.append('  if (gLastRecvTimeMulti[msgIdx][subTypeIdx] == 0)')
    lines.append('  {')
    lines.append('    gLastRecvTimeMulti[msgIdx][subTypeIdx] = currtime;')
    lines.append('    return;')
    lines.append('  }')
    lines.append('  diff = currtime - gLastRecvTimeMulti[msgIdx][subTypeIdx];')
    lines.append('  if (abs(diff - expectedCycle) > gCfgCycleToleranceMs[msgIdx])')
    lines.append('  {')
    lines.append('    gCycleFailMulti[msgIdx][subTypeIdx]++;')
    lines.append('    if (gCycleErrorReportedMulti[msgIdx][subTypeIdx] == 0)')
    lines.append('    {')
    lines.append('      gCycleErrorReportedMulti[msgIdx][subTypeIdx] = 1;')
    lines.append('      testStepFail("CYCLE_MULTI",')
    lines.append('                   "[%s] 子帧(0x%02X) 周期错误: 期望=%dms 实际=%dms 容差=%dms",')
    lines.append('                   gCfgMsgName[msgIdx], firstByte, expectedCycle, diff, gCfgCycleToleranceMs[msgIdx]);')
    lines.append('    }')
    lines.append('  }')
    lines.append('  else')
    lines.append('  {')
    lines.append('    if (gCycleErrorReportedMulti[msgIdx][subTypeIdx] == 1)')
    lines.append('      testStepPass("CYCLE_MULTI_RECOVER", "[%s] 子帧(0x%02X) 周期恢复正常", gCfgMsgName[msgIdx], firstByte);')
    lines.append('    gCycleErrorReportedMulti[msgIdx][subTypeIdx] = 0;')
    lines.append('  }')
    lines.append('  gLastRecvTimeMulti[msgIdx][subTypeIdx] = currtime;')
    lines.append('}')
    lines.append('')

    # RC/CRC 初始化
    if rc_crc_list:
        lines.append(gen_rc_crc_init(rc_crc_list))
        lines.append('')

    # on message *
    lines.append('on message *')
    lines.append('{')
    lines.append('  int idx; int i; int isFd; int payloadLen; long data[64];')
    lines.append('  byte firstByte = 0;')
    lines.append('  idx = Gen_FindMsgIndex(this.id);')
    lines.append('  isFd = this.FDF;')
    lines.append('  payloadLen = Gen_DlcToPayloadLen(this.dlc, isFd);')
    lines.append('  if (gCheckMode == MODE_MSG_ID) { if (idx < 0) return; Common_CheckOnlyMsgId(idx, this.id); return; }')
    lines.append('  if (idx < 0) return;')
    lines.append('  for (i = 0; i < 64; i++) data[i] = 0;')
    lines.append('  for (i = 0; i < payloadLen && i < 64; i++) data[i] = this.byte(i);')
    lines.append('  if (payloadLen > 0) firstByte = (byte)(data[0] & 0xFF);')
    lines.append('')
    lines.append('  switch (gCheckMode)')
    lines.append('  {')
    lines.append('    case MODE_DLC: Common_CheckOnlyDLC(idx, this.id, this.dlc); break;')
    lines.append('    case MODE_CYCLE:')
    lines.append('    {')
    if 0x515 in multi_cycle_msgs:
        lines.append('      if (this.id == 0x515)')
        lines.append('      {')
        lines.append('        Common_Check515Sequence(idx, firstByte);')

        lines.append('      }')
        lines.append('      else')
        lines.append('        Common_CheckOnlyCycle(idx, this.id);')
    else:
        lines.append('      Common_CheckOnlyCycle(idx, this.id);')
    lines.append('      break;')
    lines.append('    }')
    lines.append('    case MODE_CANFD: Common_CheckOnlyCanFd(idx, this.id, isFd); break;')
    lines.append('    case MODE_RESERVED: Common_CheckReservedAndUnusedBits(idx, this.id, data, payloadLen); break;')
    lines.append('    default: break;')
    lines.append('  }')
    lines.append('  Gen_DispatchSignalMonitor(idx, data, payloadLen);')

    if rc_crc_list:
        lines.append('  if (gCheckMode == MODE_RC_ONLY)')
        lines.append('  {')
        lines.append('    for (i = 0; i < elCount(gInstances); i++)')
        lines.append('    {')
        lines.append('      if (gInstances[i].targetId == this.id)')
        lines.append('      {')
        lines.append('        gInstances[i].frameCount++;')
        lines.append('        Check_RC_FromData(i, this.id, data, payloadLen);')
        lines.append('      }')
        lines.append('    }')
        lines.append('    return;')
        lines.append('  }')
        lines.append('')
        lines.append('  if (gCheckMode == MODE_CRC_ONLY)')
        lines.append('  {')
        lines.append('    for (i = 0; i < elCount(gInstances); i++)')
        lines.append('    {')
        lines.append('      if (gInstances[i].targetId == this.id)')
        lines.append('      {')
        lines.append('        gInstances[i].frameCount++;')
        lines.append('        Check_CRC_FromData(i, this.id, data, payloadLen);')
        lines.append('      }')
        lines.append('    }')
        lines.append('    return;')
        lines.append('  }')

    if rc_crc_list:
        lines.append('  if (gCheckMode == MODE_RC_CRC)')
        lines.append('  {')
        if 0x515 in multi_cycle_msgs:
            lines.append('    if (this.id == 0x515)')
            lines.append('    {')
            lines.append('      switch (firstByte)')
            lines.append('      {')
            sub_idx = 0
            for cycle, byteVal, desc in multi_cycle_msgs[0x515]:
                sub_idx = sub_type_map[byteVal]
                lines.append(
                    f'        case 0x{byteVal:02X}: Common_CheckMultiCycle(this.id, idx, firstByte, {sub_idx}, {cycle}); break;')
            lines.append('        default: write("未知的0x515子帧类型: 0x%02X", firstByte); break;')
            lines.append('      }')
            lines.append('    }')
            lines.append('    else')
            lines.append('      Common_CheckOnlyCycle(idx, this.id);')
        else:
            lines.append('    Common_CheckOnlyCycle(idx, this.id);')
        lines.append('')
        lines.append('    for(i=0; i<elCount(gInstances); i++)')
        lines.append('    {')
        lines.append('      if(gInstances[i].targetId == this.id)')
        lines.append('      {')
        lines.append('        Check_RC_FromData(i, this.id, data, payloadLen);')
        lines.append('        Check_CRC_FromData(i, this.id, data, payloadLen);')
        lines.append('      }')
        lines.append('    }')
        lines.append('    return;')
        lines.append('  }')
    lines.append('}')
    return '\n'.join(lines)

def build_signal_index_map(tx_messages):
    sig_index_map = {}
    global_sig_idx = 0
    for msg_idx, msg in enumerate(tx_messages):
        for sig in msg.signals:
            sig_index_map[(msg.frame_id, sig.name)] = {
                "sig_idx": global_sig_idx,
                "msg_idx": msg_idx
            }
            global_sig_idx += 1
    return sig_index_map

def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    db = cantools.database.load_file(DBC_FILE)
    # tx_messages = collect_tx_messages(db, TEST_NODE)
    # all_signals = build_signal_table(tx_messages)
    # rc_crc_list = collect_rc_crc_messages(db, TEST_NODE)
    tx_messages = collect_tx_messages(db, TEST_NODE)
    all_signals = build_signal_table(tx_messages)
    sig_index_map = build_signal_index_map(tx_messages)
    rc_crc_list = collect_rc_crc_messages(db, TEST_NODE, sig_index_map)

    cfg_text = gen_cfg(tx_messages, all_signals)
    hooks_text = gen_hooks(tx_messages, all_signals, rc_crc_list)

    with open(CFG_FILE, "w", encoding="gbk") as f:
        f.write(cfg_text)
    with open(HOOKS_FILE, "w", encoding="gbk") as f:
        f.write(hooks_text)

    print("✅ 生成完成！")
    print(f"消息：{len(tx_messages)} | 信号：{len(all_signals)} | RC/CRC组：{len(rc_crc_list)}")
    for item in rc_crc_list:
        warn = " [WARN: DataID=0]" if item['data_id'] == 0 else ""
        print(
            f"  → ID:0x{item['msg_id']:X}  MsgIdx:{item['msg_idx']}  "
            f"RC:{item['rc_signal_name']}({item['rc_sig_idx']})  "
            f"CRC:{item['crc_signal_name']}({item['crc_sig_idx']})  "
            f"DataID:0x{item['data_id']:04X}{warn}"
        )


if __name__ == "__main__":
    main()